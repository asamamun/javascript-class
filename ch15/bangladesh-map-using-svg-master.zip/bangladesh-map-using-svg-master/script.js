// Author: Shameem Reza
// URL: https://shameem.me

$ = new jQuery.noConflict();
$(document).ready(function(){
	// some sample events
	$("#division-dhaka").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Dhaka"
	})
	$("#division-chittagong").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Chittagong"
	})
	$("#division-sylhet").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Sylhet"
	})
	$("#division-khulna").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Khulna"
	})
	$("#division-barishal").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Barisal"
	})
	$("#division-rajshahi").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Rajshahi"
	})
	$("#division-rangpur").click(function(){
		window.location.href="https://en.wikipedia.org/wiki/Rangpur_City"
	})
})
