# Bangladesh Map

Bangladesh Map with sample CSS and JS added using SVG. This is just for practicing.

* Details: https://shameem.me/bangladesh-map-using-svg

You can fork and use it in anywhere.
